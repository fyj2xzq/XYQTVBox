var rule = Object.assign(muban.首图2,{
title:'LIBVIO',
host:'https://www.libvio.me',
// host:'https://www.libvio.fun',
url:'/type/fyclass-fypage.html',
class_parse:'.stui-header__menu li:gt(0):lt(7);a&&Text;a&&href;/(\\d+).html',
searchUrl:'/search/**----------fypage---.html',
});