var rule = Object.assign(muban.mxpro,{
	title:'MXONE',
    host:'https://www.jpys.me',
    url:'vodshow/fyclass--------fypage---.html',
    searchUrl:'/vodsearch/**----------fypage---.html/',
    class_name:'电影&电视剧&动漫&综艺',
    class_url:'1&2&3&4',
	class_parse:'',
});