var rule = Object.assign(muban.首图2,{
title:'在线之家',
host:'https://zxzj.vip',
});